package com.alexcarstensen.thebrandapp.model;
/**
 * Created by Peter Ring on 27/09/2016.
 */

public class Coordinates
{
    private double lon;
    private double lat;

    public double getLon()
    {
        return lon;
    }

    public double getLat()
    {
        return lat;
    }

    public void setLon(double lon_)
    {
        lon = lon;
    }

    public void setLat(double lat_)
    {
        lat = lat_;
    }
}
