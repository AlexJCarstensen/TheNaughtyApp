package com.alexcarstensen.thebrandapp.model;
/**
 * Created by Peter Ring on 27/09/2016.
 */

public class Rain
{
    private int threeHour;

    public int getThreeHour()
    {
        return threeHour;
    }

    public void setThreeHour(int threeHour_)
    {
        threeHour = threeHour_;
    }
}
