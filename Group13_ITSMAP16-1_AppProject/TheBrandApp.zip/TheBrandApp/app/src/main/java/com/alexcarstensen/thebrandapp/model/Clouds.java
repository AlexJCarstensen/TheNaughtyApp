package com.alexcarstensen.thebrandapp.model;
/**
 * Created by Peter Ring on 27/09/2016.
 */

public class Clouds
{
    private double all;

    public double getAll()
    {
        return all;
    }

    public void setFloat(double all_)
    {
        all = all_;
    }
}